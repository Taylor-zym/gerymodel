Grey model
==========

首先安装： ``pip install grey_model``

然后简单调用

``import grey_model as gm``

``gm.window()``

.. figure:: grey_model/need/2.png
    :align: center

然后即可在图像窗口下进行简单的Gm(1,1)模型的操作，按照操作指引，可以进行GM
plus ARIMA的修正模型。

GM系列的模型我在未来进行更新，相信会是一年以后吧，尽情期待。
