# 基础窗口：Grey model


首先安装： `pip install grey_model`

然后简单调用
```python
import grey_model as gm
gm.window()
```
![](grey_model/need/2.png)

然后即可在图像窗口下进行简单的Gm(1,1)模型的操作，按照操作指引，可以进行GM plus ARIMA的修正模型。

GM系列的模型我在未来进行更新，相信会是一年以后吧，尽情期待。


---
2023-11-26 我回来了，我要继续完成我的包了！！！！

# 新的方法：词云图
```python
 from grey_model.word import win
 win.win()
```

![app2](grey_model/need/app2.png)
