''''
作者：romtance
时间:2023年03月28日
'''

def main():
    return '感谢你安装Grey-model，使用过程中任何问题可以联系:romtance@163.com'